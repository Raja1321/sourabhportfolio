import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowDown, Github, Linkedin, Mail } from 'lucide-react';
import profilePhoto from '@/assets/profile-photo.jpg';

const roles = [
  'Future Software Engineer',
  'Full Stack Developer',
  'Problem Solver',
  'Tech Enthusiast',
];

const FloatingIcon = ({ children, className }: { children: React.ReactNode; className?: string }) => (
  <div className={`absolute text-2xl opacity-20 select-none ${className}`}>
    {children}
  </div>
);

const HeroSection = () => {
  const [roleIndex, setRoleIndex] = useState(0);
  const [text, setText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const currentRole = roles[roleIndex];
    let timeout: NodeJS.Timeout;

    if (!isDeleting && text === currentRole) {
      timeout = setTimeout(() => setIsDeleting(true), 2000);
    } else if (isDeleting && text === '') {
      setIsDeleting(false);
      setRoleIndex((prev) => (prev + 1) % roles.length);
    } else {
      timeout = setTimeout(
        () => {
          setText(
            isDeleting
              ? currentRole.substring(0, text.length - 1)
              : currentRole.substring(0, text.length + 1)
          );
        },
        isDeleting ? 40 : 80
      );
    }

    return () => clearTimeout(timeout);
  }, [text, isDeleting, roleIndex]);

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Gradient orbs */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 rounded-full bg-primary/10 animate-pulse-glow" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 rounded-full bg-accent/10 animate-pulse-glow" style={{ animationDelay: '1.5s' }} />

      {/* Floating tech icons */}
      <FloatingIcon className="top-[20%] left-[10%] animate-float">🐍</FloatingIcon>
      <FloatingIcon className="top-[15%] right-[15%] animate-float-delayed">☕</FloatingIcon>
      <FloatingIcon className="bottom-[30%] left-[20%] animate-float-slow">🌐</FloatingIcon>
      <FloatingIcon className="top-[40%] right-[10%] animate-float">⚡</FloatingIcon>
      <FloatingIcon className="bottom-[20%] right-[25%] animate-float-delayed">🎨</FloatingIcon>

      <div className="container mx-auto px-6 z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
          {/* Text content */}
          <motion.div
            className="flex-1 text-center lg:text-left"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <motion.p
              className="text-sm font-medium text-primary tracking-widest uppercase mb-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              Welcome to my portfolio
            </motion.p>

            <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              Hi, I'm{' '}
              <span className="text-gradient">Sourabh</span>
              <br />
              <span className="text-muted-foreground text-2xl md:text-3xl lg:text-4xl">
                {text}
                <span className="animate-pulse text-primary">|</span>
              </span>
            </h1>

            <p className="text-muted-foreground text-lg max-w-lg mx-auto lg:mx-0 mb-8">
              B.Tech CSE student passionate about building impactful software solutions.
              Turning ideas into elegant, functional code.
            </p>

            <div className="flex items-center gap-4 justify-center lg:justify-start">
              <a
                href="#projects"
                className="px-8 py-3 rounded-xl bg-gradient-primary text-primary-foreground font-semibold hover:opacity-90 transition-all hover:scale-105 glow-primary"
              >
                View Projects
              </a>
              <a
                href="#contact"
                className="px-8 py-3 rounded-xl glass font-semibold text-foreground hover:scale-105 transition-all gradient-border"
              >
                Contact Me
              </a>
            </div>

            <div className="flex items-center gap-5 mt-8 justify-center lg:justify-start">
              <a href="https://github.com/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
                <Github size={22} />
              </a>
              <a href="https://linkedin.com/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
                <Linkedin size={22} />
              </a>
              <a href="mailto:sourabh@example.com" className="text-muted-foreground hover:text-primary transition-colors">
                <Mail size={22} />
              </a>
            </div>
          </motion.div>

          {/* Profile image */}
          <motion.div
            className="flex-shrink-0"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <div className="relative">
              <div className="w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden gradient-border p-1">
                <img
                  src={profilePhoto}
                  alt="Sourabh Mahapatra - Software Developer"
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
              <div className="absolute -inset-4 rounded-full bg-gradient-primary opacity-10 blur-2xl animate-pulse-glow" />
            </div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-10 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <ArrowDown className="text-muted-foreground" size={24} />
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;

import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { GraduationCap, Code2, FolderGit2, Globe } from 'lucide-react';

const stats = [
  { icon: GraduationCap, label: 'CGPA', value: '6.72', suffix: '' },
  { icon: FolderGit2, label: 'Projects', value: '2', suffix: '+' },
  { icon: Code2, label: 'Skills', value: '5', suffix: '+' },
  { icon: Globe, label: 'Languages', value: '4', suffix: '' },
];

const AnimatedCounter = ({ value, suffix }: { value: string; suffix: string }) => {
  return (
    <span className="font-display text-3xl font-bold text-gradient">
      {value}{suffix}
    </span>
  );
};

const AboutSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="about" className="relative py-24 z-10">
      <div className="container mx-auto px-6" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="text-sm font-medium text-primary tracking-widest uppercase mb-2">Get to know me</p>
          <h2 className="font-display text-3xl md:text-4xl font-bold">About Me</h2>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="glass rounded-2xl p-8">
              <h3 className="font-display text-xl font-semibold mb-4 text-gradient">Who am I?</h3>
              <p className="text-muted-foreground leading-relaxed mb-4">
                I'm <span className="text-foreground font-medium">Sourabh Mahapatra</span>, a passionate Computer Science student
                at Gandhi Institute of Engineering and Technology University. I love turning complex problems into
                simple, beautiful, and intuitive solutions.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-6">
                My journey in tech started with curiosity and has grown into a deep passion for software development.
                I specialize in Python, Java, and web technologies, always eager to learn and build something new.
              </p>

              <div className="flex flex-wrap gap-3">
                {['English', 'Hindi', 'Odia', 'Bengali'].map((lang) => (
                  <span key={lang} className="px-4 py-1.5 rounded-full text-xs font-medium glass text-muted-foreground">
                    {lang}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <div className="grid grid-cols-2 gap-4">
              {stats.map((stat, i) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.4 + i * 0.1 }}
                  className="glass rounded-2xl p-6 text-center hover:scale-105 transition-transform cursor-default group"
                >
                  <stat.icon className="w-8 h-8 mx-auto mb-3 text-primary group-hover:text-accent transition-colors" />
                  <AnimatedCounter value={stat.value} suffix={stat.suffix} />
                  <p className="text-muted-foreground text-sm mt-1">{stat.label}</p>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: 0.8 }}
              className="mt-4 glass rounded-2xl p-6"
            >
              <h4 className="font-display font-semibold mb-3">Interests</h4>
              <div className="flex flex-wrap gap-3">
                {['🏏 Cricket', '✈️ Travelling', '🍳 Cooking'].map((interest) => (
                  <span key={interest} className="px-4 py-2 rounded-xl text-sm bg-muted text-muted-foreground hover:text-foreground transition-colors">
                    {interest}
                  </span>
                ))}
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;

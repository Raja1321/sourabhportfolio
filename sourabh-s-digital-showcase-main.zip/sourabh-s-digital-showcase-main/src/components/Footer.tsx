import { Github, Linkedin, Mail, Heart } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="relative z-10 border-t border-border py-12">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <a href="#home" className="font-display text-xl font-bold text-gradient">
              SM.
            </a>
            <p className="text-sm text-muted-foreground mt-1">
              © 2025 Sourabh Mahapatra. All rights reserved.
            </p>
          </div>

          <div className="flex items-center gap-5">
            <a href="https://github.com/" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-xl glass flex items-center justify-center text-muted-foreground hover:text-primary hover:scale-110 transition-all">
              <Github size={18} />
            </a>
            <a href="https://linkedin.com/" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-xl glass flex items-center justify-center text-muted-foreground hover:text-primary hover:scale-110 transition-all">
              <Linkedin size={18} />
            </a>
            <a href="mailto:sourabh@example.com" className="w-10 h-10 rounded-xl glass flex items-center justify-center text-muted-foreground hover:text-primary hover:scale-110 transition-all">
              <Mail size={18} />
            </a>
          </div>

          <p className="text-sm text-muted-foreground flex items-center gap-1">
            Made with <Heart size={14} className="text-destructive" /> in India
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

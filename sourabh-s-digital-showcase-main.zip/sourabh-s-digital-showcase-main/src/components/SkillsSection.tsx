import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const technicalSkills = [
  { name: 'Python', level: 80, color: 'from-primary to-accent' },
  { name: 'Java', level: 75, color: 'from-primary to-accent' },
  { name: 'SQL', level: 70, color: 'from-primary to-accent' },
  { name: 'HTML', level: 90, color: 'from-primary to-accent' },
  { name: 'CSS', level: 85, color: 'from-primary to-accent' },
  { name: 'JavaScript', level: 75, color: 'from-primary to-accent' },
];

const softSkills = [
  { name: 'Communication', icon: '💬' },
  { name: 'Leadership', icon: '🎯' },
  { name: 'Problem Solving', icon: '🧩' },
  { name: 'Teamwork', icon: '🤝' },
];

const SkillBar = ({ name, level, delay }: { name: string; level: number; delay: number }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-50px' });

  return (
    <div ref={ref} className="mb-5">
      <div className="flex justify-between mb-2">
        <span className="text-sm font-medium text-foreground">{name}</span>
        <span className="text-sm text-muted-foreground">{level}%</span>
      </div>
      <div className="h-2.5 rounded-full bg-muted overflow-hidden">
        <motion.div
          className="h-full rounded-full bg-gradient-primary"
          initial={{ width: 0 }}
          animate={isInView ? { width: `${level}%` } : { width: 0 }}
          transition={{ duration: 1, delay, ease: 'easeOut' }}
        />
      </div>
    </div>
  );
};

const SkillsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="skills" className="relative py-24 z-10">
      <div className="container mx-auto px-6" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="text-sm font-medium text-primary tracking-widest uppercase mb-2">What I know</p>
          <h2 className="font-display text-3xl md:text-4xl font-bold">Skills & Expertise</h2>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Technical Skills */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="glass rounded-2xl p-8">
              <h3 className="font-display text-xl font-semibold mb-6 text-gradient">Technical Skills</h3>
              {technicalSkills.map((skill, i) => (
                <SkillBar
                  key={skill.name}
                  name={skill.name}
                  level={skill.level}
                  delay={0.3 + i * 0.1}
                />
              ))}
            </div>
          </motion.div>

          {/* Soft Skills */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <div className="glass rounded-2xl p-8 h-full">
              <h3 className="font-display text-xl font-semibold mb-6 text-gradient">Soft Skills</h3>
              <div className="grid grid-cols-2 gap-4">
                {softSkills.map((skill, i) => (
                  <motion.div
                    key={skill.name}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={isInView ? { opacity: 1, scale: 1 } : {}}
                    transition={{ duration: 0.4, delay: 0.5 + i * 0.1 }}
                    className="p-6 rounded-xl bg-muted/50 text-center hover:scale-105 transition-transform cursor-default group"
                  >
                    <span className="text-3xl block mb-3 group-hover:scale-110 transition-transform">{skill.icon}</span>
                    <p className="text-sm font-medium text-foreground">{skill.name}</p>
                  </motion.div>
                ))}
              </div>

              <div className="mt-6 p-6 rounded-xl bg-muted/50">
                <h4 className="font-display font-semibold mb-3">Frontend Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {['HTML', 'CSS', 'JavaScript'].map((s) => (
                    <span key={s} className="px-4 py-1.5 rounded-full text-xs font-medium bg-primary/10 text-primary">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
